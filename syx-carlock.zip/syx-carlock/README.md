# syx-carlock

Simple vehicle locking system for FiveM, using **ox_lib** and **ESX**.

## Features

- Lock / unlock owned vehicles with a keybind (default: **L**)
- Key-fob raise animation, indicator-light flash, and horn chirp when locking/unlocking
- ox_target option (optional)
- Full config file
- Sounds
- Ability to share your vehicle's key with other players (`/givecarkey [id]`)
- Server-authoritative lock state — works for **any vehicle**, however it was
  spawned (personal garage, `jg-advancedgarages`, dealership, admin spawn, etc.),
  because it checks ESX's `owned_vehicles` table / granted keys by plate, not by
  which script created the vehicle
- Client exports (`GiveKey` / `RemoveKey`) so other scripts can plug in, the same
  way officially-supported key scripts like `wasabi_carlock` do

## Installation

1. Drop the `syx-carlock` folder into your server's `resources` directory.
2. Make sure `ox_lib` and `es_extended` start **before** `syx-carlock` in your `server.cfg`:
   ```cfg
   ensure ox_lib
   ensure es_extended
   ensure syx-carlock
   ```
3. If you use `ox_target`, make sure it's also started before `syx-carlock`
   (it's optional — set `Config.UseTarget = false` in `config/config.lua` if you don't use it).
4. Edit `config/config.lua` to taste (keybind, effects, distances, etc.).

## How it works

- Press **L** (rebindable in Settings → Key Bindings → FiveM → "Toggle Vehicle
  Lock") near a vehicle, or use the ox_target option, to lock/unlock it.
- The server checks whether you own the vehicle (`owned_vehicles` table) or
  have been given a key, and only then toggles the state.
- The lock state is synced to every nearby player, so the doors actually
  lock/unlock for everyone, not just the person who pressed the key.
- Locking and unlocking both play the key-fob animation, turn the headlights
  and tail/brake lights on for one second, and chirp the horn briefly.

## JG Advanced Garages integration

`jg-advancedgarages` has a **custom key system** hook that lets any key/lock
script plug in — this is the officially documented way to add support for a
script that isn't in their built-in list
(https://docs.jgscripts.com/advanced-garages/integrations/custom-key-system).
Since `syx-carlock` isn't one of their pre-built options, wire it in like this:

1. Open `jg-advancedgarages/framework/cl-functions.lua`.
2. In `Framework.Client.VehicleGiveKeys`, add an `elseif` before the final `else`:
   ```lua
   elseif Config.VehicleKeys == "syx-carlock" then
       exports['syx-carlock']:GiveKey(plate)
   ```
3. In `Framework.Client.VehicleRemoveKeys`, do the same:
   ```lua
   elseif Config.VehicleKeys == "syx-carlock" then
       exports['syx-carlock']:RemoveKey(plate)
   ```
4. In `jg-advancedgarages/config/config.lua`, set:
   ```lua
   Config.VehicleKeys = "syx-carlock"
   ```
   > Note: JG's own docs say to use `"none"` here for a fully custom system,
   > since their built-in `Config.VehicleKeys` list doesn't recognize the
   > name `"syx-carlock"` — either value works as long as it isn't one of
   > JG's preset names, since that's what routes the call into your new
   > `elseif` branch. Test both if you're unsure; `"none"` is the
   > documented default for custom integrations.

Once that's in place, any time JG hands a player keys to a vehicle taken out
of (or put into) a garage, it calls straight into `syx-carlock`'s exports,
so the vehicle is immediately lockable with **L** — no matter which garage
type (public, private, job, impound) it came from.

This same export pattern (`GiveKey(plate)` / `RemoveKey(plate)`) is generic,
so it also works for any other script that supports a "custom key system"
integration in the same way (dealerships, valet scripts, etc.) — just call
`exports['syx-carlock']:GiveKey(plate)` from wherever that script hands out
vehicle access.

## Notes / limitations

- Shared keys (`SharedKeys` / `/givecarkey`) are stored **in memory** and
  reset on resource/server restart. If you want them to persist, add a
  small database table (e.g. `plate`, `identifier`) and load/save it in
  `server/main.lua`'s `grantKey`/`revokeKey` handlers — the structure is
  already isolated there to make that easy to extend.
- `Config.RequireOwnership = true` is strongly recommended for live servers.
  Only disable it for testing.

## Files

```
syx-carlock/
├── fxmanifest.lua
├── config/
│   └── config.lua
├── client/
│   └── main.lua
├── server/
│   └── main.lua
└── README.md
```
